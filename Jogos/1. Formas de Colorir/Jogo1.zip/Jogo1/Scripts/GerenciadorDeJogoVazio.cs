﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GerenciadorDeJogoVazio : MonoBehaviour
{
    // Não alterar
    [Header("Configurações de Formas e Cores")]
    [SerializeField]
    private Text _formaAtualTxt;
    [SerializeField]
    private Text _corAtualTxt;
    [SerializeField]
    private string[] _nomesFormas;
    [SerializeField]
    private string[] _nomesCores;
    [SerializeField]
    private Mesh[] _meshFormas;
    [SerializeField]
    private Material[] _materialCores;
    [SerializeField]
    private GameObject _formaObj;

    [Header("Pontuação")]
    [SerializeField]
    private Text _pontuacaoAtualTxt;

    private MeshFilter _meshFilterForma;
    private MeshRenderer _meshRendererForma;

    void Start()
    {
        _meshFilterForma = _formaObj.GetComponent<MeshFilter>();
        _meshRendererForma = _formaObj.GetComponent<MeshRenderer>();
        SorteiaNovoRound();
    }
    // Não alterar

    // Codifique a partir desta linha
    [Header("Crie novas variáveis aqui")]
    [SerializeField]
    private string _exemplo = "exemplo";


    public void SorteiaNovoRound()
    {
        // Sorteia uma forma e uma cor dos arrays _nomesFormas e _nomesCores
        // Para atualizar o texto do UI, faça:
        // _formaAtualTxt.text = nomeDaNovaForma;
        // _corAtualTxt.text = nomeDaNovaCor;
    }
    
    void Update()
    {
        // Seleciona a forma pressionada pelo jogador
        // [...] Codigo que seleciona forma
        // Dica: Usar _meshFilterForma.mesh = novaForma;

        // Seleciona a cor Pressionada pelo jogador
        // [...] Codigo que seleciona cor
        // Dica: Usar _meshRendererForma.material = novaCor;

        // Verificar forma e cor atual
        // Se estiver selecionada corretamente, adiciona um ponto e sorteia novo round
        // Usando o método SorteiaNovoRound() e a variavel _pontuacaoAtualTxt, que é o texto da pontuação
        // [...] Codigo que verifica forma e cor
    }



}
